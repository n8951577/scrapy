import scrapy
from scrapy_splash import SplashRequest
class dynamic(scrapy.Spider):
    name = "quoteJS"

    start_urls = ["http://quotes.toscrape.com/js/"]

    def start_requests(self):
        for url in self.start_urls:
            yield SplashRequest(url=url, callback=self.parse, endpoint='render.html')


    def parse(self, response):
        for quote in response.css("div.quote"):
            yield {
                'text': quote.css('span.text::text').extract(),
                'author': quote.css('small.author::text').extract(),
                'tags': quote.css('div.tags a.tag::text').extract(),
            }




