-- Database: `quotesdb`
-- --------------------------------------------------------
--
-- Table structure for table `quotesdb`
--

CREATE TABLE `quotesdb` (
  `text` varchar(2000) DEFAULT NULL,
  `author` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

