import pymysql
from journal.items import JournalItem

class JournalPipeline(object):
    def __init__(self):
        self.conn = pymysql.connect(host="localhost", user="root", passwd="kiran", db="journal", charset="utf8",
                                    use_unicode=True)
        self.cursor = self.conn.cursor()
        #self.cursor.execute("CREATE TABLE IF NOT EXISTS tbl(journalname varchar(2000),link varchar(2000),societyname varchar(2000))")
        self.conn.commit()


        # Deleting the duplicate Columns in the table
        self.cursor.execute("DELETE from tbl where journalname=" + str('journalname'))

    def process_item(self, item, spider):
        try:
            self.cursor.execute("""INSERT INTO tbl(journalname,link,societyname)
                                    VALUES (%s, %s, %s)""",
                        (item['journalname'],item['link'],item['societyname']))
            self.conn.commit()
        except Exception as e:
            print ("Error %d: %s" % (e.args[0], e.args[1]))

            return item