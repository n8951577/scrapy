import scrapy
from journal.items import JournalItem
from journal.pipelines import JournalPipeline
from scrapy import link
from scrapy_splash import SplashRequest

class JournalSpider(scrapy.Spider):
    name = "society"
    allowed_domains = ["ariessys.com"]
    start_urls = ['https://www.ariessys.com/journals-list/',]

    def start_requests(self):
        for url in self.start_urls:
            yield SplashRequest(url=url,callback=self.parse,endpoint='render.html')

    def parse(self, response):

        for sel in response.xpath('//div[@id="journals_list"]/table/tbody/tr[*]'):
            item = JournalItem()
            item['journalname'] = sel.xpath('td[1]/a/text()').extract()
            item['link'] = sel.xpath('td[1]/a/@href').extract()
            item['societyname'] = sel.xpath('td[2]/text()').extract()
            yield item