import json
import pymysql

rawdata = json.load(open('https://jsonplaceholder.typicode.com'))
#input_file = open('data.json', 'r')
output_file = open('output.json', 'w')

for row in rawdata:
    my_dict = {}
    my_dict['userId'] = row.get('userId')
    my_dict['id'] = row.get('id')
    my_dict['title'] = row.get('title')
    my_dict['body'] = row.get('body')
    back_json = json.dumps(my_dict, output_file)
    output_file.write(back_json)

    # establishing a connection
    conn = pymysql.connect(host="localhost", user="root", passwd="kiran", db="json")
    cursor = conn.cursor()

    # INSERT INTO data ('userId','id',title','body') VALUES ('["", "123", "hello"]')
    cursor.execute("INSERT INTO data1(userId,id,title,body)"
                   "VALUES (%s,%s,%s,%s)",
                   (my_dict['userId'], my_dict['id'], my_dict['title'], my_dict['body']))
    conn.commit()
    print('The data is successfully Saved in "data.sql" file')

