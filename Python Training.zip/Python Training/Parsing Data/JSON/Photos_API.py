import pymysql
import requests
import json

response = requests.get("https://jsonplaceholder.typicode.com/photos")

data = json.loads(response.content)
for row in data:

    my_dict = {}
    my_dict['albumId'] = row.get('albumId')
    my_dict['id'] = row.get('id')
    my_dict['title'] = row.get('title')
    my_dict['url'] = row.get('url')
    my_dict['thumbnailUrl'] = row.get('thumbnailUrl')
    #try:
     #   if(my_dict['url']=='http://placehold.it/600/771796'):
      #      print (my_dict)
    #except Exception as e:
     #   print("The records are not found for the particular URL")


    #print(my_dict)

    conn = pymysql.connect(host="localhost", user="root", passwd="kiran", db="API")
    cursor = conn.cursor()

    cursor.execute("Insert into `Photos`(albumId,id,title,url,thumbnailUrl)"
                   "values(%s,%s,%s,%s,%s)",
                   (my_dict['albumId'],my_dict['id'],my_dict['title'],my_dict['url'],my_dict['thumbnailUrl']))

    cursor.execute('SELECT * FROM Photos')
    count = 0
    for row in cursor:
        print (row)
        count = count + 1
    print (count, 'rows.')
    cursor.close()
    #conn.commit()

