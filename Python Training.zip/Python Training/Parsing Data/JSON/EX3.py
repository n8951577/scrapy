import pymysql
import requests
import json

# Make a get request to get the latest position of the international space station from the opennotify api.
response = requests.get("https://jsonplaceholder.typicode.com/posts")

# Print the response code 200 if everything id OK
print(response.status_code)

#Print the content of the webpage
#print(response.content)

# Get the response data as a python object.
data = json.loads(response.content)
#print(data)
for row in data:
#	print(d['name'])
    my_dict = {}
    my_dict['userId'] = row.get('userId')
    my_dict['id'] = row.get('id')
    my_dict['title'] = row.get('title')
    my_dict['body'] = row.get('body')

    print (my_dict)

    # establishing a connection
    conn = pymysql.connect(host="localhost", user="root", passwd="kiran", db="json")
    cursor = conn.cursor()

    # INSERT INTO data ('userId','id',title','body') VALUES ('["", "123", "hello"]')
    cursor.execute("INSERT INTO data1(userId,id,title,body)"
                   "VALUES (%s,%s,%s,%s)",
                   (my_dict['userId'], my_dict['id'], my_dict['title'], my_dict['body']))
    conn.commit()
print('The data is successfully Saved in "data.sql" file')