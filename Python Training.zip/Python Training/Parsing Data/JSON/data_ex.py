

#!/usr/bin/env python
import json
import pprint
import requests


payload = {'sql': 'SELECT * FROM json.data'}
url = "https://jsonplaceholder.typicode.com/posts"

r = requests.post(url, data=payload)

print (r.status_code)
try:
    pprint.pprint(json.loads(r.text))
except:
    pprint.pprint(r.text)

#Read from the URL
import urllib, json
url = "https://jsonplaceholder.typicode.com/posts"
response = urllib.urlopen(url)
data = json.loads(response.read())
print (data)




import json
from pprint import pprint
data = json.load("/home/kiran/Python/JSON/data.json")
pprint(data)

