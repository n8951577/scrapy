import pymysql
import requests
import json

response = requests.get("https://jsonplaceholder.typicode.com/users")

#Print the content of the webpage
#print(response.content)

# Get the response data as a python object.
data = json.loads(response.content)
for row in data:

    my_dict = {}
    my_dict['id'] = row.get('id')
    my_dict['name'] = row.get('name')
    my_dict['username'] = row.get('username')
    my_dict['email'] = row.get('email')
    my_dict['phone'] = row.get('phone')
    my_dict['website'] = row.get('website')
    my_dict['street'] = row.get('address').get('street')
    my_dict['suite'] = row.get('address').get('suite')
    my_dict['city'] = row.get('address').get('city')
    my_dict['zipcode'] = row.get('address').get('zipcode')
    my_dict['lat'] = row.get('address').get('geo').get('lat')
    my_dict['lng'] = row.get('address').get('geo').get('lng')
    my_dict['name'] = row.get('company').get('name')
    my_dict['catchPhrase'] = row.get('company').get('catchPhrase')
    my_dict['bs'] = row.get('company').get('bs')


    conn = pymysql.connect(host="localhost", user="root", passwd="kiran", db="API1")
    cursor = conn.cursor()

    cursor.execute("INSERT INTO address(street, suite, city, zipcode,lat,lng)"
                   "VALUES(%s,%s,%s,%s,%s,%s)",
                   (my_dict['street'],my_dict['suite'],my_dict['city'],my_dict['zipcode'],my_dict['lat'],my_dict['lng']))
    address = cursor.lastrowid
    print (address)

    cursor.execute("insert INTO company(name,catchPhrase,bs) VALUES(%s,%s,%s)",(my_dict['name'], my_dict['catchPhrase'],my_dict['bs']))
    company = cursor.lastrowid
    print (company)

    #When the 'id' is Primary key in that time instead of using Insert statement we use Replace
    #cursor.execute("REPLACE INTO user(id,name,username,email,phone,website,address_id,company_id)"
     #              "VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
      #             (my_dict['id'], my_dict['name'], my_dict['username'], my_dict['email'], my_dict['phone'],
       #             my_dict['website'],address,company))

    cursor.execute("Insert INTO user(id,name,username,email,phone,website,address_id,company_id)"
                   "VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                   (my_dict['id'], my_dict['name'], my_dict['username'], my_dict['email'], my_dict['phone'],
                    my_dict['website'], address, company))

    # By using 'LAST_INSERT_ID()' inbuilt function for finding the last inserted id in the table
    #cursor.execute("REPLACE INTO user(id,name,username,email,phone,website,address_id,company_id)"
     #              "VALUES (%s,%s,%s,%s,%s,%s,LAST_INSERT_ID(),LAST_INSERT_ID())",(my_dict['id'], my_dict['name'], my_dict['username'], my_dict['email'], my_dict['phone'],
      #              my_dict['website']))


    #cursor.execute("SELECT DISTINCT id,name,username,email,phone,website FROM user")
    conn.commit()


