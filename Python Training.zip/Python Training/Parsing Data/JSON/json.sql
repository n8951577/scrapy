-- Database: `json`
-- --------------------------------------------------------
--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `userId` text NOT NULL,
  `id` text NOT NULL,
  `title` text NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
-- Table structure for table `data1`

CREATE TABLE `data1` (
  `userId` text NOT NULL,
  `id` text NOT NULL,
  `title` text NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
-- Table structure for table `data3`

CREATE TABLE `data3` (
  `id` text NOT NULL,
  `name` text NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `website` text NOT NULL,
  `street` varchar(200) NOT NULL,
  `suite` text NOT NULL,
  `city` varchar(200) NOT NULL,
  `zipcode` text NOT NULL,
  `lat` varchar(200) NOT NULL,
  `lng` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--


