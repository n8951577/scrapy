# Libraries
import json, requests
import pandas as pd
from pandas.io.json import json_normalize

# Set URL
url='https://jsonplaceholder.typicode.com/posts'
#url = 'https://api-v2.themuse.com/jobs'

# For loop to
for i in range(100):

    data = json.loads(requests.get(url=url,params={'page': i}).text)['results']

    data_norm = pd.read_json(json.dumps(data))

