import json
import pymysql

input_file=open('data.json', 'r')
output_file=open('output.json', 'w')
json_decode=json.load(input_file)

for row in json_decode:
    my_dict={}
    my_dict['userId'] = row.get('userId')
    my_dict['id'] = row.get('id')
    my_dict['title'] = row.get('title')
    my_dict['body'] = row.get('body')

    #print (my_dict)
    back_json=json.dumps(my_dict, output_file)
    output_file.write(back_json)

#output_file.close()

#establishing a connection

    conn = pymysql.connect(host="localhost", user="root", passwd="kiran", db="json")
    cursor = conn.cursor()

#INSERT INTO data ('userId','id',title','body') VALUES ('["", "123", "hello"]')
    cursor.execute("INSERT INTO data(userId,id,title,body)"
               "VALUES (%s,%s,%s,%s)",
               (my_dict['userId'],my_dict['id'],my_dict['title'],my_dict['body']))
    conn.commit()
print('The data is successfully Saved in "data.sql" file')

