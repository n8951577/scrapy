import json
import requests
from urllib import urlopen
import json
import urllib3

#url = urlopen('https://jsonplaceholder.typicode.com/posts').read()
#print (url)

# Make a get request to get the latest position of the international space station from the opennotify api.
response = requests.get("https://jsonplaceholder.typicode.com/users")

# Print the response code 200 if everything id OK
print(response.status_code)

#Print the content of the webpage
#print(response.content)

# Get the response data as a python object.
data = json.loads(response.content)
#print(data)
for d in data:
    print(d['name'])

#print(data)
