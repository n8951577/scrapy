#To store a list in a .csv file


list = [[1, 2], [2, 3], [4, 5]]

#open a file in write mode
csv = open('file.csv', 'w')
for row in list:
    for column in row:
        csv.write('%d: ' % column)
    csv.write('\n')
csv.close()