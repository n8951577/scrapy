import pyexcel as pe
data=[[1, 2], [2, 3], [4, 5]]
sheet = pe.Sheet(data)
sheet
