import xml.etree.ElementTree as ET
import csv
tree = ET.parse("catalog.xml")
root = tree.getroot()

# open a file for writing
Catalog_data = open('catalog.csv', 'w')

# create the csv writer object
csvwriter = csv.writer(Catalog_data)
list= []
size=[]

count = 0
for member in root.findall('product/catalog_item'):
    catalog_item = []
    if count == 0:
        item_number = member.find('item_number').tag
        list.append(item_number)

        price = member.find('price').tag
        list.append(price)

        csvwriter.writerow(list)
        count = count + 1

    item_number = member.find('item_number').text
    catalog_item.append(item_number)

    price = member.find('price').text
    catalog_item.append(price)

    csvwriter.writerow(catalog_item)

    print(catalog_item)

Catalog_data.close()

