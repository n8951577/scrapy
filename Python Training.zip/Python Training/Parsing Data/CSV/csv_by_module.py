import csv
with open('test.csv', 'w') as f:
    list = csv.writer(f, delimiter= ' ')
    list.writerows( [[1, 2], [2, 3], [4, 5]])

with open('test.csv', 'r') as f:
    for line in f:
        print (line,)