import xml.etree.ElementTree as ET
import csv

tree = ET.parse("data.xml")
root = tree.getroot()

# open a file for writing
Company_data = open('data.csv', 'w')

# create the csv writer object
csvwriter = csv.writer(Company_data)
list = []

count = 0
for member in root.findall('Company'):
    company = []
    address_list = []
    if count == 0:
        name = member.find('Name').tag
        list.append(name)

        PhoneNumber = member.find('PhoneNumber').tag
        list.append(PhoneNumber)

        EmailAddress = member.find('EmailAddress').tag
        list.append(EmailAddress)

        Address = member[3].tag
        list.append(Address)

        csvwriter.writerow(list)
        count = count + 1

    name = member.find('Name').text
    company.append(name)

    PhoneNumber = member.find('PhoneNumber').text
    company.append(PhoneNumber)

    EmailAddress = member.find('EmailAddress').text
    company.append(EmailAddress)

    Address = member[3][0].text
    address_list.append(Address)

    City = member[3][1].text
    address_list.append(City)

    StateCode = member[3][2].text
    address_list.append(StateCode)

    PostalCode = member[3][3].text
    address_list.append(PostalCode)

    company.append(address_list)
    csvwriter.writerow(company)

Company_data.close()
