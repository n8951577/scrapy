import pymysql
import csv

with open('/home/kiran/Python/CSV/multiple_rows/data.csv') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        #print(row['Name'], row['PhoneNumber'], row['EmailAddress'], row['Address'])
        conn = pymysql.connect(host='localhost', user='root', passwd='kiran', db='xml')
        cur = conn.cursor()

        #Delete a Duplicate Rows in a table -'tbl'
        #cur.execute("DELETE FROM tbl_multi where PhoneNumber=" + str('PhoneNumber'))

        #Inserting a data
        cur.execute("INSERT INTO `tbl_multi`(`Name` ,`PhoneNumber`,`EmailAddress`, `Address`)"
                    "VALUES (%s,%s,%s, %s)",
                    (row['Name'], row['PhoneNumber'], row['EmailAddress'], row['Address']))

        #To know the count
        #cur.execute("select Name, PhoneNumber, EmailAddress, Address from tbl_multi group by Name,PhoneNumber,EmailAddress,Address having count(*) > 1")

        cur.execute("DROP TABLE `temp`")
        cur.execute("CREATE TABLE `temp` "
                    "SELECT DISTINCT * FROM `tbl_multi`")

        conn.commit()

