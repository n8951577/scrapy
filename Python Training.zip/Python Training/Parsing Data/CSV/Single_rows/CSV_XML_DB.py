import pymysql
import csv

#path = "/home/kiran/Python"
with open('/home/kiran/Python/CSV/Single_rows/data1.csv') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        print(row['Name'], row['PhoneNumber'], row['EmailAddress'], row['Address'])

        # insert
        conn = pymysql.connect(host='localhost', user='root', passwd='kiran', db='xml')
        cur = conn.cursor()

        #Delete a Duplicate Rows in a table -'tbl'
        cur.execute("Drop table `temp_single`")
        cur.execute("Create table `temp_single` select Distinct * from `tbl`")

        #Inserting a data
        cur.execute("INSERT INTO `tbl`(`Name` ,`PhoneNumber`,`EmailAddress`, `Address`)VALUES (%s,%s,%s, %s)",(row['Name'], row['PhoneNumber'], row['EmailAddress'], row['Address']))
        conn.commit()