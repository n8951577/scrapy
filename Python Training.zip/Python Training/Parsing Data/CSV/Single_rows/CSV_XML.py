import xml.etree.ElementTree as ET
import csv
tree = ET.parse("data1.xml")
root = tree.getroot()

# open a file for writing
Company_data = open('data1.csv', 'w+')

# create the csv writer object
csvwriter = csv.writer(Company_data)
list= []

count = 0
for member in root.findall('Company'):
	company = []
	if count == 0:
		name = member.find('Name').tag
		list.append(name)

		PhoneNumber = member.find('PhoneNumber').tag
		list.append(PhoneNumber)

		EmailAddress = member.find('EmailAddress').tag
		list.append(EmailAddress)

		Address = member.find('Address').tag
		list.append(Address)

		csvwriter.writerow(list)
		count = count + 1

	name = member.find('Name').text
	company.append(name)

	PhoneNumber = member.find('PhoneNumber').text
	company.append(PhoneNumber)

	EmailAddress = member.find('EmailAddress').text
	company.append(EmailAddress)

	Address = member.find('Address').text
	company.append(Address)

	csvwriter.writerow(company)

Company_data.close()