#Decision making
#Usage of if and else statements

# NAME="Kiran"
# if [ "$NAME" = "Kirn" ]; then
#   echo "True - my name is Kiran"
# else
#   echo " No plz enter correct name"
# fi

#Usage of elif

# NAME="Kiran"
# if [ "$NAME" = "Kiran" ]; then
#   echo "True - my name is Kiran"
# elif [ "$NAME" = "Praveen" ];then
# #   echo " sa;duiap9"
# else
#   echo "Plz enter a correct name"
# fi

