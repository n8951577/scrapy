
function add
    {
        echo "$(($1 + $2))"
    }
function minus
    {
        echo "$(($1 - $2))"
    }
function multiply
    {
        echo "$(($1 * $2))"
    }

# FUNCTION CALLS
# Pass two parameters to each function
add 3 5        #8
minus 5 1        #4
multiply 4 6        #24
