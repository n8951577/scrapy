val=`expr 2 + 2`
echo "the result is: $val"

#OPERATORS
a=10
b=20
val=`expr $a + $b`
echo "a + b : $val"
echo "Addition: `expr $a + $b`"