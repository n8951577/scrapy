#Looping
#1. For loop

Names=(Kiran Praveen Chetan)
for N in ${Names[@]};
do
    echo "The names are $N"
done