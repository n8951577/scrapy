#Example
#echo "what is your name?"
#read PERSON
#echo "Your name is , $PERSON"


#VARIABLES
#Defining a variable NAME="Kiran"
echo "Defining a variable-->NAME="Kiran""
NAME="Kiran"

#Accessing a variable
echo "Accessing a variable"
NAME="Praveen"
echo $NAME


#Make the variable as READ-ONLY
NAME = "Pavan"
readonly NAME
NAME = "Chetan"

#Make the Variable as UNSET
NAME = "Pavan"
UNSET NAME
echo $NAME


