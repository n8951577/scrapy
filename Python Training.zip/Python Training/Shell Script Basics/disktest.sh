printf 'Which Linux distribution do you know? '
read DISTR

case $DISTR in
     ubuntu)
          echo "You're entered an UNIX FLAVOUR OS"
          ;;
     centos|rhel)
          echo "SERVER OS"
          ;;
     windows)
          echo "Microsoft Product"
          ;; 
     *)
          echo "Please enter a correct Operating system"
          ;;
esac