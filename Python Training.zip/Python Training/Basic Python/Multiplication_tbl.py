#multiplication table
num = int(input('Enter the number to print the multiplication table'))
for i in range(1,11):
    print(num,'x',i,'=',num*i)
    