list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
list2 = [1, 2, 22, 5, 478, 6, 2]
list(set(list1).intersection(list2))
list3 = []
list3 = (set(list1).union(list2))
print(list)
print(list3)