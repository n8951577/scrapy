my_list = [1,23,4,2,14,5,3,6,8,5,99,10]
n = int(input('Enter a Number :  '))
print('The elements in the given list are', my_list)
if n in my_list:
    print('Number is found in the list')
else:
    print('Not found')

