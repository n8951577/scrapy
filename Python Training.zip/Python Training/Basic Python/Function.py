#function defination and call
def greet(name):
    print("Hi" + name +"Good morning") #It displays a msg Hai Kiran Good morning
greet('Kiran')  #Function Call


def greet(year):
    print("DOB is %d" %year)
greet(201)



def name(name):
    print("Yofdur name is "+name)
name('Kirana')

