a = 10
b = 20
b1 = 20

#Arithmetic Operators
c = a + b
d = a - b
e = a * b
f = a / b
g = b // a    #Floar
h = a % b
i = b ** a    #Exponential

#Printing the results
#print(c,d,e,f,g,h,i, end = '\n')
print('\n\n')
#Comparison operators
c1 = a > b
d1 = a < b
e1 = a>=b
print(b == b)

print(c1,d1,e1)
print('\n\n')


#Logical Operators
x = 'True'
y = 'False'
print('x and y -->', x and y)
print('x or y -->', x or y)
print('y , not y -->', y,not y)
print('x , not x -->', x,not x)
print('\n\n')

#Membership Operators
m = "Welcome to Impelsys"
print('Usage of in operator -->','Impelsys' in m)
print('Usage of in operator -->','impelsys' in m)
print('Usage of not in operator -->','Impelsys' not in m)
print('\n\n')

#Identity Operator
print ('is operator -->',a,b,a is b)
print ('is not operator -->',a,b,a is not b)
print ('is not operator -->',a,b,b is not b)



