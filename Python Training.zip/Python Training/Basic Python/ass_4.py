def number():
    n=int(input("Please enter a Number"))
    if(n%2==0):
        print("Even Number")
    else:
        print("Odd number")
number()