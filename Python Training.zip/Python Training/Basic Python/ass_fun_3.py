def square():  #function defn
    n=dict()
    for i in range(1, 4):
        n[i] = i ** 2   #exponential
    print(n)
square()    #function Call