#Integers
a = 10

print("-"*40)
print("Integers ")
print("-"*40)
print("a = ",a)

#Float
b = 1.2345

print("-"*40)
print("Float ")
print("-"*40)
print('b = ',b)

#Long int
c=1000000000000L;
print(c)

