# To print a name of a variable by creting a Class
class MyClass:
    variable = "Kiran"

    def function(self):
        print("This is a message inside the class.")

myobjectx = MyClass()
print(myobjectx.variable)   #print a Variable ='Kiran'
myobjectx.function()        #print a msg written inside a function
