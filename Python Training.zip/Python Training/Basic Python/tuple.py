a=(1,2,3,'hai',-68,0.8)
print(a)
print(a[2])
#del(a[2])
print(a[-2])

print(a[2:5])


#Update a tuple
x=(10,20,30,40)
y=(50,60,70)
z=x+y
print(x,y,z)
print(z)

#We cant able to update any items from the tuple because it is an immutable list- Can't be Modified.


#Delete an Entire tuple
del(x)
print(x)

