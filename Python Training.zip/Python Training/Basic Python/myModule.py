class Person():
    name= ' '
    def sayHello(self):
        print('Your name is %s' %self.name)
