#Integers
a = 10

print("-"*40)
print("Integers ")
print("-"*40)
print("a = ",a)

#Float
b = 1.2345

print("-"*40)
print("Float ")
print("-"*40)
print('b = ',b)


#Strings
stringSingleQuote = 'tutorial'
stringDoubleQuote = "tutorial"
documentString = '''tutorial'''

print("-"*40)
print("Strings ")
print("-"*40)
print("stringSingleQuote = ",stringSingleQuote)
print("stringSingleQuote = ",stringSingleQuote)
print("documentString = ",documentString)

#Boolean
c = True
d = False

print("-"*40)
print("Boolean ")
print("-"*40)
print('c = ',c)
print('d = ',d)

#Lists
IntList = [1,2,3,4,5]
stringList = ['india','usa','australia','china']
floatList = [1.2,3.4,2.0,4.1]
combinedDataList = [1,'india',2.5]

print("-"*40)
print("List ")
print("-"*40)
print ("IntList = ",IntList)
print ("stringList = ",stringList)
print ("floatList = ",floatList)
print ("combinedDataList = ",combinedDataList)
print(IntList*2)

#Tuples
intTuple = (1,2,3,4)
stringTuple = ("sunday","monday","tuesday","wednesday","thursday",'friday','saturday')
floatTuple = (1.2,3.2,1.0)

print("-"*40)
print("Tuples ")
print("-"*40)
print ("intTuple = ",intTuple)
print ("stringTuple = ",stringTuple)
print ("floatTuple = ",floatTuple)

#dictionary
dictionary1 = {'key1':'value1','key2':'value2'}
dictionary2 = {'a':1,'b':2}
dictionary3 = {1:'a',2:'b'}


print("-"*40)
print("dictionary ")
print("-"*40)
print('dictionary1 = ',dictionary1)
print('dictionary2 = ',dictionary2)
print('dictionary3 = ',dictionary3)

#Sets
set2 = set(['a','b','c','d','a'])
set3 = {1,2,3,4,5,2}

print("-"*40)
print("Sets ")
print("-"*40)
print('set2 = ',set2)
print('set3 = ',set3)