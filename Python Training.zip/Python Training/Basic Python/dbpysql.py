from __future__ import print_function

import pymysql

conn = pymysql.connect(host='localhost', user='root', passwd='kiran', db='mysql')

cur = conn.cursor()

cur.execute("SELECT Host,User FROM user")

print(cur.description)

print()

cur.close()
conn.close()
