#USage of for loop

string = 'hello world'
print string
for char in string:
    print char


#Usage of Functions
a=[1,2,3,4,5,6]
n=sum(a)
print (a,n)


def s():
    return 2,1,2
x,y,z=s()

print(x)

