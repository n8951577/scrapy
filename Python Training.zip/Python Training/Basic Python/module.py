from myModule import Person
Person1 = Person()
Person1.name ='Kiran'
Person1.sayHello()
