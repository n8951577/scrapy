import sys
if len(sys.argv) != 2:
    print ("The list of arguments passed ")
    sys.exit(0)