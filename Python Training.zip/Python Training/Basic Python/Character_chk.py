ch=input('Enter a Character')
if ((ch>='a' and ch<='z')or(ch>='A' and ch<='Z')):
    print(ch, 'is a Valid Character')
else:
    print(ch, 'is not a valid Character Please check it...')
