class Car(object):
    def setSpeed(self,speed):
        print('Going this fast:%d' %speed)

class Truck(object):
    def setSpeed(self,speed):
        print('Going this fast:%d' %speed)