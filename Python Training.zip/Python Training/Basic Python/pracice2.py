for line in open('/home/kiran/Python/Python_Example/ass_4.py'):
      print (line.strip())