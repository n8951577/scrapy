a = 40
b = a
c = [b]

del a       #The object 'a = 40' id deleted
b=10        #the variable b is assigned to b=10
c[0] = -1

# For printing the values
#print(a)
print(b)
print(c)

