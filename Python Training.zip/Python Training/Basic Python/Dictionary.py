my_dict = { }                             #empty dictionary
my_dict1 = {1:'Kiran'}                     #with Key:Value pair
my_dict2 = {1:'Praveen',2:'Chetan'}
my_dict3 = {'name':'Kirana',1:'[2,3,4]'}       #with mixed values

print(my_dict3['name'])
print(my_dict2[1])

# Trying to access keys which doesn't exist throws error
#my_dict2.get('address')
# my_dict['address']


#Updating

my_dict2 [1] = " ki rna "
print(my_dict2)

#add

my_dict = ["hai"]
my_dict = ["haisds"]

print(my_dict)

my_dict1[2] = 'TutorialsCloud' ;
my_dict1[3]= '10 Percent';
print(my_dict1)




