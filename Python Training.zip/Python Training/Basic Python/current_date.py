#To know the current System Date and time
import datetime
current_date_time=datetime.datetime.today()
print(current_date_time)


# to

dir(datetime)
date=datetime.date(2017,3,13)
print(date)
print(date.year)
print(date.timetuple())

