import sys
print('Welcome to python Terminal')

name = input ('Enter your Name : ')
age = int(input('Enter your Age Please : '))

print('Your Name is:'+name+'and your Age is: %d' %age)

print('Thank you')


#def parse(self, response):
 #   filename = response.url.split("/")[-2] + ".html"
  #  with open(filename, "wb") as f:
   #     f.write(response.body)


