def square():  #function defn
    n=dict()
    #n1=dict()
    #print(n)
    for i in range(1, 21):
        n[i] = i ** 2   #exponential-- For SQUARE
     #   n1[i] = i ** 3 #For CUBE
    print(n)
    #print(n1)
square()    #function Call