# coding:utf-8


from scrapy import cmdline

cmdline.execute("scrapy crawl music".split())
cmdline.execute("scrapy crawl video".split())
