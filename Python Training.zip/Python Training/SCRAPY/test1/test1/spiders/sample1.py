import scrapy
class ConfierSpider(scrapy.Spider):
    name="confiers"
    allowed_domains=["greatplantpicks.com"]
    start_urls=["http://www.greatplantpicks.org/plantlists/search/"]

    def parse(self,response):
        filename=response.url.split("/")[-2] + '.html'
        with open(filename,'wb') as f:
            f.write(response.body)