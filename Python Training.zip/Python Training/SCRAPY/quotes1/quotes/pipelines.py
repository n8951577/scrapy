import pymysql
from quotes.items import QuotesItem

class QuotesPipeline(object):
    def __init__(self):
        self.conn= pymysql.connect(user='root', passwd='kiran', host='localhost',db='quotesdb',use_unicode=True,charset='utf8')
        self.cursor = self.conn.cursor()
        self.cursor.execute("CREATE TABLE IF NOT EXISTS quotesdb(text VARCHAR(2000), author VARCHAR(200), tags VARCHAR(2000))")
        self.conn.commit()

    def process_item(self, item, spider):
        self.cursor.execute("INSERT INTO quotesdb(text,author,tags) VALUES (%s, %s, %s)",(item['text'],item['author'],item['tags'] ))
        self.conn.commit()
        return item