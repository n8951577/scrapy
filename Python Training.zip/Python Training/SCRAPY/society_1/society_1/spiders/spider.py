import scrapy
class societyspider(scrapy.Spider):
    name="society"

#    def start_requests(self):
# urls=[
#             'https://www.ariessys.com/journals-list/',
#          ]
#         for url in urls:
#             yield scrapy.Request(url=url,callback=self.parse)

# #clones the webpage
#             def parse(self, response):
#                 page=response.url.split("/")[-2]
#                 filename='society_1-%s.html' %page
#                 with open(filename,'wb') as f:
#                     f.write(response.body)
    allowed_domains=['ariessys.com']
    start_urls=['https://www.ariessys.com/journals-list/']

    def parse(self,response):
        filename=response.url.split("/")[-2]+ '.html'
        with open(filename,'wb') as f:
            f.write(response.body)
