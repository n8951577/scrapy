import scrapy
from quotes.items import QuotesItem
from quotes.pipelines import QuotesPipeline

class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = [
        'http://quotes.toscrape.com/page/1/',
        'http://quotes.toscrape.com/page/2/'
    ]

    def parse(self, response):
        for quote in response.css('div.quote'):
            yield {
                'text': quote.css('span.text::text').extract(),
#                'text': quote.xpath('//span[@class="text"]').extract(),
                'author': quote.css('small.author::text').extract(),
#                'author': quote.xpath('//small[@class="author"]').extract(),
                #'tags': quote.css('div.tags a.tag::text').extract(),
            }

