import scrapy
from scrapy.shell import inspect_response

class flipkartspider(scrapy.Spider):
    name = "flipkart"
    allowed_domains = ["flipkart.com"]
    start_urls=["https://www.flipkart.com/"]

    def parse(self, response):
        inspect_response(response,self);
        