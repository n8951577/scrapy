import pymysql

class CraigsPipeline(object):
    def __init__(self):
        self.conn= pymysql.connect(user='root', passwd='kiran', host='localhost',db='craig',use_unicode=True,charset='utf8')
        self.cursor = self.conn.cursor()
        self.conn.commit()
    #Deleting the duplicate Columns in the table
        #self.cursor.execute("DELETE from craigs where text=" + str('text'))
    def process_item(self, item, spider):
        self.cursor.execute("INSERT INTO craig_tbl(title,link) VALUES (%s,%s)",(item['title'], item['link']))
        self.conn.commit()
        return item