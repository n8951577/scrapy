import scrapy
from scrapy_splash import SplashRequest
from craigs.items import CraigsItem

class MySpider(scrapy.Spider):
        name = "craig"
        allowed_domains = ["craigslist.org"]
        start_urls = ["http://sfbay.craigslist.org/sfc/npo/"]

        def start_requests(self):
            for url in self.start_urls:
                yield SplashRequest(url=url, callback=self.parse, endpoint='render.html')

        def parse(self, response):
            divs = response.xpath('//p[@class="result-info"]')
            for div in divs:
                item = CraigsItem()
                item['title']= [i.strip() for i in div.xpath('//a//text()').extract()]
                item['link']= div.xpath('//a//@href').extract()
            return item