import scrapy
class Impelsys(scrapy.Spider):
    name = "Impelsys"
    allowed_urls=["impelsys.com/"]
    start_urls=["https://www.impelsys.com/careers/"]

    def parse(self, response):
        filename=response.url.split("/")[-2] +".html"
        with open(filename,"wb") as f:
            f.write(response.body)

