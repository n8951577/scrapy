import scrapy
from conifers.items import ConifersItem

class coniferSpider(scrapy.Spider):
    name = "conifers_org"
    allowed_domains=['greatplantpicks.org']
    start_urls=['http://www.greatplantpicks.org/plantlists/by_plant_type/conifer']

#Extract name, species,genus

    def parse(self,response):
        for sel in response.xpath("//tbody/tr"):
            item = ConifersItem()
            item['name'] = sel.xpath('td[@class="common-name"]/a/text()').extract()
            item['genus'] = sel.xpath('td[@class="plantname"]/a/span[@class="genus"]/text()').extract()
            item['species'] = sel.xpath('td[@class="plantname"]/a/span[@class="species"]/text()').extract()
            yield item


