import scrapy

class ConifersItem(scrapy.Item):
    name = scrapy.Field()
    genus = scrapy.Field()
    species = scrapy.Field()
    pass