import scrapy
from scrapy.shell import inspect_response
class sit(scrapy.Spider):
    name = "sit"
    allowed_domains=["sit.ac.in"]
    start_urls=["http://www.sit.ac.in/"]

    def parse(self, response):
        inspect_response(response,self)
