import scrapy
from hindu.items import HinduItem

class hindu(scrapy.Spider):
    name = "hindu"
    allowed_domains=['thehindu.com']
    start_urls=['http://www.thehindu.com/']
    def parse(self, response):
        papers=response.xpath("//*[@class='story-card']")
        for paper in papers:
            item = HinduItem()

            #It prints all the headings in the h2 and h3 style
            item['headlines'] = paper.xpath("//div[@class='story-card-news']//h2 | //h3//text()")
            #item['headlines'] = paper.xpath("//*[self::h2]//a//text()")
            return item