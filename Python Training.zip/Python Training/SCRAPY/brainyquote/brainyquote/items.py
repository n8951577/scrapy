import scrapy


class BrainyquoteItem(scrapy.Item):
    #name = scrapy.Field()
    #author = scrapy.Field()
    text = scrapy.Field()
    pass
