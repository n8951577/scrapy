import pymysql

from brainyquote.items import BrainyquoteItem

class BrainyquotePipeline(object):
    def __init__(self):
        self.conn= pymysql.connect(user='root', passwd='kiran', host='localhost',db='brainy',use_unicode=True,charset='utf8')
        self.cursor = self.conn.cursor()
        self.cursor.execute("CREATE TABLE IF NOT EXISTS brainy(text VARCHAR(200))")
        self.conn.commit()

    #Deleting the duplicate Columns in the table
        #self.cursor.execute("DELETE from brainy where text=" + str('text'))

    def process_item(self, item, spider):
        #print item['text']
        data=("""INSERT INTO brainy(text) VALUES (%s)""", (item['text']))
        self.cursor.execute(data)
        self.conn.commit()
        return item

