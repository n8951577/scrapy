import scrapy
from brainyquote.items import BrainyquoteItem
from brainyquote.pipelines import BrainyquotePipeline


class BrainySpider(scrapy.Spider):
    name = "brainyquotes"
    allowed_domains=['brainyquote.com']
    start_urls = ['https://www.brainyquote.com/topics/website']

    def parse(self, response):
        quotes=response.xpath('//*[@id="quotesList"]')
        for quote in quotes:
            item=BrainyquoteItem()

            #By using the title  - XPATH

            #item['name'] = quote.xpath('//*[@title="view quote"]//text()').extract()
            #item['author'] = quote.xpath('//*[@title="view author"]//text()').extract()
            #item['text'] = quote.xpath('//a[@class="oncl_k"]//text()').extract()

            # By using the title  - CSS SELECTOR
            item['text'] = quote.css('a.oncl_k::text').extract()

            # Extract the quotes
            # item['name'] = quote.xpath('//a[@class="b-qt qt_410951 oncl_q"]//text()').extract()
            #XPATH for extracting all the items including new lines
            #item['text'] = quote.xpath('//*[@class="kw-box"]//text()').extract()

            yield item